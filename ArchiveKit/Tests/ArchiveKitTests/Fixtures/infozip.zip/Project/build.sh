#!/bin/sh
cc src/main.c
